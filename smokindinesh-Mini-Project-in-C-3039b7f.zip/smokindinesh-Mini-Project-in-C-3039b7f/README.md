# About

Mini Projects written in C for begineer. Detail of all projects are in http://codeincodeblock.com/

List of articles:

 1. [Libray management](http://www.codeincodeblock.com/2011/03/mini-project-library-management-in-c.html)
 2. [Snake Game](http://www.codeincodeblock.com/2011/06/mini-projet-snake-game-in-c.html)
 3. [Quiz Game](http://www.codeincodeblock.com/2011/06/mini-project-quiz-in-c.html)
 4. [Department store system](http://www.codeincodeblock.com/2011/06/mini-project-department-store-source.html)
 5. [Tic-tac-toe game](http://www.codeincodeblock.com/2011/06/mini-project-tic-tac-game-source-code.html)
 6. [Personal Dairy Management System](http://www.codeincodeblock.com/2012/06/school-project-personal-dairy.html)
 7. [Telecom Billing Management System](http://www.codeincodeblock.com/2012/06/telecom-billing-management-system-in-c.html)
 8. [Bank Management System](http://www.codeincodeblock.com/2012/06/codeblocks-project-bank-management.html)
 9. [Contacts Management](http://www.codeincodeblock.com/2011/09/contacts-manager-mini-project-in-c-with.html)
 10. [Medical Store Management System](http://www.codeincodeblock.com/2012/08/c-project-on-medical-store-management.html)
